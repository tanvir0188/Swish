from django.db.models.signals import post_save
from django.dispatch import receiver
from accounts.models import User
from .models import CompanyProfile
import random
import string

@receiver(post_save, sender=User)
def create_company_profile(sender, instance, created, **kwargs):
    if created and instance.role == 'company':
        # Create a CompanyProfile linked to the new user
        CompanyProfile.objects.create(user=instance,company_name=instance.full_name, phone_number=instance.telephone, location=instance.address, business_email=instance.email )