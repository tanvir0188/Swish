from django.contrib import admin

from service_provider.models import CompanyProfile

# Register your models here.
admin.site.register(CompanyProfile)